package com.facens.app_biblioteca_api.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.facens.app_biblioteca_api.model.Livro;
import com.facens.app_biblioteca_api.service.LivroService;

@RestController

@RequestMapping("/livros")

public class LivroController {

    private final LivroService livroService;

    public LivroController(LivroService livroService) {
        this.livroService = livroService;
    }

    @GetMapping
    public List<Livro> ListarLivros() {
        return livroService.listarTodos();
    }

    @GetMapping("/teste")
    public String testeAPI() {
        return "API funcionando corretamente";
    }

    @GetMapping("/{id}")
    public Livro buscaPorId(@PathVariable Long id) {
        return livroService.buscarPorId(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Livro criarLivro(@RequestBody Livro livro) {
        return livroService.criar(livro);
    }

    @PutMapping("/{id})")
    public Livro atualizarLivro(@PathVariable Long id, @RequestBody Livro livro) {
        return livroService.atualizar(id, livro);
    }

    @DeleteMapping
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void removerLivro(@PathVariable Long id) {
        livroService.deletar(id);
    }

    @PutMapping("{id}/emprestar")
    public Livro emprestarLivro(@PathVariable Long id) {
        return livroService.emprestar(id);
    }

    @PutMapping("/{id}/devolver")
    public Livro devolverLivro(@PathVariable Long id) {
        return livroService.devolver(id);
    }

}
